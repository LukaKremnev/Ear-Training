package com.example.eartraining2;

import android.content.Context;
import android.media.SoundPool;

import java.util.HashMap;

public class SoundManager {
    private SoundPool soundPool;
    private HashMap<String, Integer> soundMap;
    private Context context;

    public SoundManager(Context context) {
        this.context = context;
        soundPool = new SoundPool.Builder().setMaxStreams(10).build();
        soundMap = new HashMap<>();
    }

    public void loadSound(String noteName) {
        int resId = context.getResources().getIdentifier(noteName, "raw", context.getPackageName());
        if (resId != 0 && !soundMap.containsKey(noteName)) {
            int soundId = soundPool.load(context, resId, 1);
            soundMap.put(noteName, soundId);
        }
    }

    public void playSound(String noteName) {
        Integer soundId = soundMap.get(noteName);
        if (soundId != null) {
            soundPool.play(soundId, 1, 1, 1, 0, 1f);
        }
    }
}