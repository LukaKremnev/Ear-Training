package com.example.eartraining2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class FinishedSoloGameActivity extends AppCompatActivity {

    private int mistakes;
    private String selectedMode, selectedDifficulty, selectedTestSize;
    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private DocumentReference statsRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.finished_solo);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        statsRef = db.collection("statistics").document(user.getUid());



        mistakes = getIntent().getIntExtra("mistakes", 0);
        selectedMode = getIntent().getStringExtra("selectedMode");
        selectedDifficulty = getIntent().getStringExtra("selectedDifficulty");
        selectedTestSize = getIntent().getStringExtra("selectedTestSize");
        int correctAnswers = getIntent().getIntExtra("correctAnswers", 0);

        int totalGames = correctAnswers + mistakes;
        if (totalGames == 0) totalGames = 1;
        double successRate = (double) correctAnswers / totalGames;

        String starsEarned;
        if (successRate <= 0.5) {
            starsEarned = "★";
        } else if (successRate < 0.8) {
            starsEarned = "★★";
        } else {
            starsEarned = "★★★";
        }

        int starsNumeric = starsEarned.length();

        statsRef.get().addOnSuccessListener(document -> {
            if (document.exists()) {
                long totalStars = document.getLong("stars") != null ? document.getLong("stars") : 0;
                long totalPlays = document.getLong("totalPlays") != null ? document.getLong("totalPlays") : 0;

                Map<String, Object> updates = new HashMap<>();
                updates.put("stars", totalStars + starsNumeric);
                updates.put("totalPlays", totalPlays + 1);

                String difficultyKey = selectedDifficulty.toLowerCase();
                String difficultyGamesKey = difficultyKey + "Games";
                String difficultyRateKey = difficultyKey + "Rate";

                long gamesPlayed = document.getLong(difficultyGamesKey) != null ? document.getLong(difficultyGamesKey) : 0;
                long totalCorrect = Math.round(document.getLong(difficultyRateKey) != null ? document.getLong(difficultyRateKey) * gamesPlayed / 100.0 : 0);

                long newGamesPlayed = gamesPlayed + 1;
                long newCorrect = totalCorrect + correctAnswers;
                long newRate = Math.round((double) newCorrect / (newGamesPlayed * (correctAnswers + mistakes > 0 ? 1 : 1)) * 100);

                updates.put(difficultyGamesKey, newGamesPlayed);
                updates.put(difficultyRateKey, newRate);

                String modeKey = selectedMode.toLowerCase();
                String modeGamesKey = modeKey + "Games";
                String modeStarsKey = modeKey + "Stars";

                long modeGames = document.getLong(modeGamesKey) != null ? document.getLong(modeGamesKey) : 0;
                String prevStars = document.getString(modeStarsKey);
                double prevAvg = parseStarRating(prevStars);
                double newAvg = (prevAvg * modeGames + starsNumeric) / (modeGames + 1);
                String newStarsFormatted = formatStarRating(newAvg);

                updates.put(modeGamesKey, modeGames + 1);
                updates.put(modeStarsKey, newStarsFormatted);

                statsRef.update(updates)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(this, "Statistics updated", Toast.LENGTH_SHORT).show();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Failed to update stats: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        });
            }
        });

        TextView mistakesText = findViewById(R.id.statistics_mistakes);
        TextView resultMessage = findViewById(R.id.result_message);
        TextView numberOfStars = findViewById(R.id.number_of_stars);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        mistakesText.setText("Mistakes: " + mistakes);
        numberOfStars.setText(starsEarned);

        if (successRate <= 0.5) {
            resultMessage.setText("Try again!");
        } else if (successRate < 0.8) {
            resultMessage.setText("Good job!");
        } else {
            resultMessage.setText("Excellent!");
        }

        findViewById(R.id.next_button).setOnClickListener(v -> restartGame());
        findViewById(R.id.exit_button).setOnClickListener(v -> exitToHome());
    }

    private void restartGame() {
        Intent intent = new Intent(this, SoloPlayActivity.class);
        intent.putExtra("selectedMode", selectedMode);
        intent.putExtra("selectedDifficulty", selectedDifficulty);
        intent.putExtra("selectedTestSize", selectedTestSize);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
        overridePendingTransition(0, 0);
    }

    private void exitToHome() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        overridePendingTransition(0, 0);
        finish();
        overridePendingTransition(0, 0);
    }

    private double parseStarRating(String stars) {
        if (stars == null) return 0;
        int count = 0;
        for (char c : stars.toCharArray()) {
            if (c == '★') count++;
        }
        return count;
    }

    private String formatStarRating(double average) {
        if (average < 1.5) return "★☆☆";
        else if (average < 2.5) return "★★☆";
        else return "★★★";
    }
}