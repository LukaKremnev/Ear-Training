package com.example.eartraining2;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;

public class EndlessSoloPlayActivity extends AppCompatActivity {

    private Button pauseButton, playNoteButton, playCNoteButton, finishButton;
    private TextView gamesPlayedText, selectedModeText, selectedDifficultyText, answerFeedbackText;
    private FrameLayout soloGameInterface;
    private MediaPlayer mediaPlayer;
    private int gamesPlayed = 0;
    private int mistakesCount = 0;
    private String selectedMode, selectedDifficulty;
    private ArrayList<String> notesPool;
    private String currentNote;
    private boolean isNoteAnswered = true;
    private final Handler handler = new Handler();
    private Button playIntervalButton, answerButton;
    private ArrayList<String> intervalPool;
    private String firstNote, secondNote;
    private MediaPlayer firstPlayer, secondPlayer;
    private Button playChordButton, answerChordButton, displayChordButton;
    private TextView answerFeedbackTextChords;
    private Spinner chordsSpinner;
    private ArrayList<String> chordPool;
    private String rootNote, chordType;
    private ArrayList<String> currentChordNotes;
    private MediaPlayer[] chordPlayers;
    private boolean isChordAnswered = true;
    private TextView chordNotesLabel;
    private String[] allNotes = {
            "c3", "csharp3", "d3", "dsharp3", "e3", "f3", "fsharp3", "g3", "gsharp3", "a3", "asharp3", "b3",
            "c4", "csharp4", "d4", "dsharp4", "e4", "f4", "fsharp4", "g4", "gsharp4", "a4", "asharp4", "b4",
            "c5", "csharp5", "d5", "dsharp5", "e5", "f5", "fsharp5", "g5", "gsharp5", "a5", "asharp5", "b5"
    };
    private int correctAnswers = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.endless_solo_play);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        Intent intent = getIntent();
        selectedMode = intent.getStringExtra("selectedMode");
        selectedDifficulty = intent.getStringExtra("selectedDifficulty");

        pauseButton = findViewById(R.id.pause_button);
        finishButton = findViewById(R.id.finish_button);
        gamesPlayedText = findViewById(R.id.games_played);
        selectedModeText = findViewById(R.id.selected_mode);
        selectedDifficultyText = findViewById(R.id.selected_difficulty);
        soloGameInterface = findViewById(R.id.solo_game_interface);

        selectedModeText.setText("Mode: " + selectedMode);
        selectedDifficultyText.setText("Difficulty: " + selectedDifficulty);
        updateGamesPlayedText();

        loadGameInterface(selectedMode);

        pauseButton.setOnClickListener(v -> pauseGame());
        finishButton.setOnClickListener(v -> finishGame());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (firstPlayer != null) {
            firstPlayer.release();
            firstPlayer = null;
        }
        if (secondPlayer != null) {
            secondPlayer.release();
            secondPlayer = null;
        }
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    private void pauseGame() {
        Intent intent = new Intent(this, SoloPauseActivity.class);

        intent.putExtra("selectedMode", selectedMode);
        intent.putExtra("selectedDifficulty", selectedDifficulty);
        intent.putExtra("selectedTestSize", "∞");

        startActivity(intent);
    }

    private void updateGamesPlayedText() {
        gamesPlayedText.setText("Games Played: " + gamesPlayed);
    }

    private void loadGameInterface(String mode) {
        int layoutId;

        if (mode.equals("Notes")) {
            layoutId = R.layout.notes_solo_game_interface;
        } else if (mode.equals("Intervals")) {
            layoutId = R.layout.intervals_solo_game_interface;
        } else if (mode.equals("Chords")) {
            layoutId = R.layout.chords_solo_game_interface;
        } else {
            return;
        }

        View gameView = LayoutInflater.from(this).inflate(layoutId, soloGameInterface, false);
        soloGameInterface.removeAllViews();
        soloGameInterface.addView(gameView);

        if (mode.equals("Notes")) {
            setupNotesGame(gameView);
        } else if (mode.equals("Intervals")) {
            setupIntervalsGame(gameView);
        } else if (mode.equals("Chords")) {
            setupChordsGame(gameView); // ✅ Добавляем настройку аккордов
        }
    }

    private void setupNotesGame(View gameView) {
        playNoteButton = gameView.findViewById(R.id.play_note_button);
        playCNoteButton = gameView.findViewById(R.id.play_c_note_button);
        answerFeedbackText = gameView.findViewById(R.id.answer_feedback_text);

        generateNotesPool();

        playNoteButton.setOnClickListener(v -> {
            if (isNoteAnswered) {
                playRandomNote();
                isNoteAnswered = false;
            } else {
                repeatCurrentNote();
            }
        });

        if (playCNoteButton != null) {
            playCNoteButton.setOnClickListener(v -> playNoteSound("c4"));
        }

        setupPianoKeys(gameView);
    }

    private void setupIntervalsGame(View gameView) {
        playIntervalButton = gameView.findViewById(R.id.play_interval_button);
        answerButton = gameView.findViewById(R.id.answer_button);
        answerFeedbackText = gameView.findViewById(R.id.answer_feedback_text);
        Spinner intervalSpinner = gameView.findViewById(R.id.intervals_spinner);

        if (playIntervalButton == null || answerButton == null || intervalSpinner == null) {
            Log.e("EndlessSoloPlayActivity", "setupIntervalsGame: One or more UI elements are null!");
            return;
        }

        ArrayList<String> availableIntervals = new ArrayList<>();

        if (selectedDifficulty.equals("Easy")) {
            availableIntervals.add("Unison");
            availableIntervals.add("Minor second");
            availableIntervals.add("Major second");
            availableIntervals.add("Minor third");
            availableIntervals.add("Major third");
            availableIntervals.add("Perfect fourth");
            availableIntervals.add("Perfect fifth");
        } else if (selectedDifficulty.equals("Medium")) {
            availableIntervals.add("Unison");
            availableIntervals.add("Minor second");
            availableIntervals.add("Major second");
            availableIntervals.add("Minor third");
            availableIntervals.add("Major third");
            availableIntervals.add("Perfect fourth");
            availableIntervals.add("Perfect fifth");
            availableIntervals.add("Minor sixth");
            availableIntervals.add("Major sixth");
            availableIntervals.add("Minor seventh");
            availableIntervals.add("Major seventh");
            availableIntervals.add("Octave");
        } else { // Hard
            Collections.addAll(availableIntervals, "Unison", "Minor second", "Major second", "Minor third",
                    "Major third", "Perfect fourth", "Tritone", "Perfect fifth", "Minor sixth",
                    "Major sixth", "Minor seventh", "Major seventh", "Octave");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, availableIntervals);
        intervalSpinner.setAdapter(adapter);

        generateIntervalPool();

        playIntervalButton.setOnClickListener(v -> playRandomInterval());
        answerButton.setOnClickListener(v -> checkIntervalAnswer());
    }

    private void setupChordsGame(View gameView) {
        playChordButton = gameView.findViewById(R.id.play_chord_button);
        answerChordButton = gameView.findViewById(R.id.check_chord_button);
        displayChordButton = gameView.findViewById(R.id.display_chord_button);
        answerFeedbackTextChords = gameView.findViewById(R.id.answer_feedback_text);
        chordNotesLabel = gameView.findViewById(R.id.chord_notes_label);
        chordsSpinner = gameView.findViewById(R.id.chords_spinner);

        if (playChordButton == null || answerChordButton == null || displayChordButton == null || chordsSpinner == null) {
            Log.e("EndlessSoloPlayActivity", "setupChordsGame: One or more UI elements are null!");
            return;
        }

        ArrayList<String> availableChords = new ArrayList<>();
        if (selectedDifficulty.equals("Easy")) {
            Collections.addAll(availableChords, "Major", "Minor", "Diminished", "Augmented");
        } else if (selectedDifficulty.equals("Medium")) {
            Collections.addAll(availableChords, "Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th");
        } else { // Hard
            Collections.addAll(availableChords, "Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th",
                    "Sixth", "Ninth", "Eleventh", "Thirteenth");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, availableChords);
        chordsSpinner.setAdapter(adapter);

        generateChordPool();

        playChordButton.setOnClickListener(v -> playRandomChord());
        answerChordButton.setOnClickListener(v -> checkChordAnswer());
        displayChordButton.setOnClickListener(v -> displayCorrectChord());
    }

    private void generateNotesPool() {
        String[] baseNotes = {"c", "csharp", "d", "dsharp", "e", "f", "fsharp", "g", "gsharp", "a", "asharp", "b"};
        notesPool = new ArrayList<>();

        if (selectedDifficulty.equals("Easy")) {
            for (String note : baseNotes) {
                notesPool.add(note + "4");
            }
        } else if (selectedDifficulty.equals("Medium")) {
            for (String note : baseNotes) {
                notesPool.add(note + "3");
                notesPool.add(note + "4");
            }
        } else {
            for (String note : baseNotes) {
                notesPool.add(note + "3");
                notesPool.add(note + "4");
                notesPool.add(note + "5");
            }
        }
        Collections.shuffle(notesPool);
    }

    private void generateIntervalPool() {
        Log.d("generateIntervalPool", "♻ Generating new interval pool...");

        intervalPool = new ArrayList<>();
        HashSet<String> uniqueIntervals = new HashSet<>();
        Random random = new Random();

        ArrayList<Integer> availableDistances = new ArrayList<>();

        if (selectedDifficulty.equals("Easy")) {
            Collections.addAll(availableDistances, 0, 1, 2, 3, 4, 5, 7);
        } else if (selectedDifficulty.equals("Medium")) {
            Collections.addAll(availableDistances, 0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12);
        } else { // Hard
            Collections.addAll(availableDistances, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        }

        while (uniqueIntervals.size() < 20) {
            int firstIndex = random.nextInt(allNotes.length - 12);
            int distance = availableDistances.get(random.nextInt(availableDistances.size()));
            int secondIndex = firstIndex + distance;

            if (secondIndex >= allNotes.length) continue;

            String firstNote = allNotes[firstIndex];
            String secondNote = allNotes[secondIndex];

            uniqueIntervals.add(firstNote + "_" + secondNote);
        }

        intervalPool = new ArrayList<>(uniqueIntervals);
        Collections.shuffle(intervalPool);
    }

    private void generateChordPool() {
        chordPool = new ArrayList<>();
        Random random = new Random();

        String[] allChordTypes;
        if (selectedDifficulty.equals("Easy")) {
            allChordTypes = new String[]{"Major", "Minor", "Diminished", "Augmented"};
        } else if (selectedDifficulty.equals("Medium")) {
            allChordTypes = new String[]{"Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th"};
        } else {
            allChordTypes = new String[]{"Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th",
                    "Sixth", "Ninth", "Eleventh", "Thirteenth"};
        }

        for (String chord : allChordTypes) {
            int randomNoteIndex = random.nextInt(allNotes.length - 12);
            String root = allNotes[randomNoteIndex];
            chordPool.add(root + "_" + chord);
        }

        Collections.shuffle(chordPool);
    }

    private ArrayList<String> generateChordNotes(String root, String chordType) {
        int rootIndex = -1;
        for (int i = 0; i < allNotes.length; i++) {
            if (allNotes[i].equals(root)) {
                rootIndex = i;
                break;
            }
        }

        if (rootIndex == -1) return new ArrayList<>();

        ArrayList<String> chordNotes = new ArrayList<>();
        chordNotes.add(allNotes[rootIndex]);

        switch (chordType) {
            case "Major":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                break;
            case "Minor":
                if (rootIndex + 3 < allNotes.length) chordNotes.add(allNotes[rootIndex + 3]); // m3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                break;
            case "Diminished":
                if (rootIndex + 3 < allNotes.length) chordNotes.add(allNotes[rootIndex + 3]); // m3
                if (rootIndex + 6 < allNotes.length) chordNotes.add(allNotes[rootIndex + 6]); // dim5
                break;
            case "Augmented":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 8 < allNotes.length) chordNotes.add(allNotes[rootIndex + 8]); // aug5
                break;
            case "Dominant 7th":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                if (rootIndex + 10 < allNotes.length) chordNotes.add(allNotes[rootIndex + 10]); // m7
                break;
            case "Major 7th":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                if (rootIndex + 11 < allNotes.length) chordNotes.add(allNotes[rootIndex + 11]); // M7
                break;
            case "Minor 7th":
                if (rootIndex + 3 < allNotes.length) chordNotes.add(allNotes[rootIndex + 3]); // m3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                if (rootIndex + 10 < allNotes.length) chordNotes.add(allNotes[rootIndex + 10]); // m7
                break;
            case "Sixth":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                if (rootIndex + 9 < allNotes.length) chordNotes.add(allNotes[rootIndex + 9]); // M6
                break;
            case "Ninth":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                if (rootIndex + 10 < allNotes.length) chordNotes.add(allNotes[rootIndex + 10]); // m7
                if (rootIndex + 14 < allNotes.length) chordNotes.add(allNotes[rootIndex + 14]); // M9
                break;
            case "Eleventh":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                if (rootIndex + 10 < allNotes.length) chordNotes.add(allNotes[rootIndex + 10]); // m7
                if (rootIndex + 14 < allNotes.length) chordNotes.add(allNotes[rootIndex + 14]); // M9
                if (rootIndex + 17 < allNotes.length) chordNotes.add(allNotes[rootIndex + 17]); // P11
                break;
            case "Thirteenth":
                if (rootIndex + 4 < allNotes.length) chordNotes.add(allNotes[rootIndex + 4]); // M3
                if (rootIndex + 7 < allNotes.length) chordNotes.add(allNotes[rootIndex + 7]); // P5
                if (rootIndex + 10 < allNotes.length) chordNotes.add(allNotes[rootIndex + 10]); // m7
                if (rootIndex + 14 < allNotes.length) chordNotes.add(allNotes[rootIndex + 14]); // M9
                if (rootIndex + 17 < allNotes.length) chordNotes.add(allNotes[rootIndex + 17]); // P11
                if (rootIndex + 21 < allNotes.length) chordNotes.add(allNotes[rootIndex + 21]); // M13
                break;
        }

        return chordNotes;
    }


    private void playRandomNote() {
        if (notesPool.isEmpty()) {
            generateNotesPool();
        }

        currentNote = notesPool.remove(0);
        playNoteSound(currentNote);
        gamesPlayed++;
        updateGamesPlayedText();
    }

    private void playRandomInterval() {
        if (intervalPool.isEmpty()) {
            generateIntervalPool();
        }

        if (intervalPool.isEmpty()) {
            Log.e("playRandomInterval", "❌ Interval pool is still empty after regeneration! Skipping interval playback.");
            return;
        }

        String[] interval = intervalPool.get(0).split("_");
        firstNote = interval[0];
        secondNote = interval[1];

        if (firstNote == null || secondNote == null) {
            Log.e("playRandomInterval", "❌ firstNote or secondNote is NULL! Skipping playback.");
            return;
        }

        int firstSoundId = getResources().getIdentifier(firstNote, "raw", getPackageName());
        int secondSoundId = getResources().getIdentifier(secondNote, "raw", getPackageName());

        if (firstSoundId == 0 || secondSoundId == 0) {
            Log.e("playRandomInterval", "❌ Sound file not found: " + firstNote + " or " + secondNote);
            return;
        }

        if (firstPlayer != null) {
            firstPlayer.release();
            firstPlayer = null;
        }
        if (secondPlayer != null) {
            secondPlayer.release();
            secondPlayer = null;
        }

        firstPlayer = MediaPlayer.create(this, firstSoundId);
        secondPlayer = MediaPlayer.create(this, secondSoundId);

        if (firstPlayer == null || secondPlayer == null) {
            Log.e("playRandomInterval", "❌ MediaPlayer is NULL! Skipping playback.");
            return;
        }

        firstPlayer.start();

        handler.postDelayed(() -> {
            if (secondPlayer != null) {
                secondPlayer.start();
            }
        }, 400);
    }

    private void playRandomChord() {
        if (isChordAnswered) {
            if (chordPool.isEmpty()) {
                generateChordPool();
            }

            String[] chordInfo = chordPool.remove(0).split("_");
            rootNote = chordInfo[0];
            chordType = chordInfo[1];
            currentChordNotes = generateChordNotes(rootNote, chordType);

            isChordAnswered = false;
        }

        playChord(currentChordNotes);
    }

    private void playChord(ArrayList<String> chordNotes) {
        if (chordNotes == null || chordNotes.isEmpty()) return;

        chordPlayers = new MediaPlayer[chordNotes.size()];
        for (int i = 0; i < chordNotes.size(); i++) {
            int soundId = getResources().getIdentifier(chordNotes.get(i), "raw", getPackageName());
            if (soundId != 0) {
                chordPlayers[i] = MediaPlayer.create(this, soundId);
            }
        }

        Handler handler = new Handler();
        for (int i = 0; i < chordPlayers.length; i++) {
            int finalI = i;
            handler.postDelayed(() -> {
                if (chordPlayers[finalI] != null) {
                    chordPlayers[finalI].start();
                }
            }, 400 * finalI);
        }
    }

    private void repeatCurrentNote() {
        if (currentNote == null) return;
        playNoteSound(currentNote);
    }

    private void playNoteSound(String note) {
        int soundId = getResources().getIdentifier(note, "raw", getPackageName());
        if (soundId != 0) {
            mediaPlayer = MediaPlayer.create(this, soundId);
            if (mediaPlayer != null) {
                mediaPlayer.start();
            }
        }
    }

    private void finishGame() {
        Intent intent = new Intent(this, FinishedSoloGameActivity.class);
        intent.putExtra("mistakes", mistakesCount);
        intent.putExtra("correctAnswers", correctAnswers);
        intent.putExtra("selectedMode", selectedMode);
        intent.putExtra("selectedDifficulty", selectedDifficulty);
        intent.putExtra("gamesPlayed", gamesPlayed);
        startActivity(intent);
        overridePendingTransition(0, 0); // Убираем анимацию перехода
        finish();
        overridePendingTransition(0, 0); // Убираем анимацию закрытия
    }

    private void showFeedbackChords(String message, boolean correct) {
        if (answerFeedbackTextChords != null) {
            answerFeedbackTextChords.setText(message);
            answerFeedbackTextChords.setTextColor(correct ? 0xFF008800 : 0xFFFF0000);
            answerFeedbackTextChords.setVisibility(View.VISIBLE);

            handler.postDelayed(() -> answerFeedbackTextChords.setVisibility(View.INVISIBLE), 1500);
        }
    }

    private String formatChordNotes(ArrayList<String> chordNotes) {
        ArrayList<String> formattedNotes = new ArrayList<>();
        for (String note : chordNotes) {
            String formattedNote = note.replaceAll("[0-9]", "");
            formattedNote = formattedNote.substring(0, 1).toUpperCase() + formattedNote.substring(1);
            formattedNote = formattedNote.replace("sharp", "#");
            formattedNotes.add(formattedNote);
        }
        return String.join(" - ", formattedNotes);
    }



    private void setupPianoKeys(View parentView) {
        int[] whiteKeys = {R.id.c_4, R.id.d_4, R.id.e_4, R.id.f_4, R.id.g_4, R.id.a_4, R.id.b_4};
        int[] blackKeys = {R.id.c_sharp_4, R.id.d_sharp_4, R.id.f_sharp_4, R.id.g_sharp_4, R.id.a_sharp_4};

        View.OnClickListener listener = v -> {
            if (isNoteAnswered) return;

            String pressedNote = getResources().getResourceEntryName(v.getId())
                    .replace("_4", "")
                    .replace("_sharp", "sharp");

            String expectedNote = currentNote.replaceAll("[0-9]", "");

            if (pressedNote.equals(expectedNote)) {
                playNoteSound(pressedNote + "4");
                showFeedback("Correct!", true);
                isNoteAnswered = true;
                correctAnswers++; // ✅ Добавлено увеличение счета правильных ответов
            } else {
                mistakesCount++;
                showFeedback("Wrong! Correct: " + formatNoteName(currentNote), false);
            }
        };

        for (int key : whiteKeys) {
            parentView.findViewById(key).setOnClickListener(listener);
        }
        for (int key : blackKeys) {
            parentView.findViewById(key).setOnClickListener(listener);
        }
    }

    private void showFeedback(String message, boolean correct) {
        if (answerFeedbackText != null) {
            answerFeedbackText.setText(message);
            answerFeedbackText.setTextColor(correct ? 0xFF008800 : 0xFFFF0000);
            answerFeedbackText.setVisibility(View.VISIBLE);

            handler.postDelayed(() -> answerFeedbackText.setVisibility(View.INVISIBLE), 1000);
        }
    }

    private String formatNoteName(String note) {
        return note.replace("sharp", "#").replaceAll("[0-9]", "").toUpperCase();
    }

    private String lastCorrectInterval = "";
    private boolean isIntervalAnswered = false;

    private void checkIntervalAnswer() {
        Spinner intervalSpinner = findViewById(R.id.intervals_spinner);
        String selectedInterval = intervalSpinner.getSelectedItem().toString();

        if (firstNote == null || secondNote == null) {
            Log.e("checkIntervalAnswer", "❌ Cannot check interval answer: firstNote or secondNote is NULL!");
            return;
        }

        String correctInterval = calculateInterval(firstNote, secondNote);

        if (selectedInterval.equals(correctInterval)) {
            showFeedback("Correct!", true);
            correctAnswers++;
            gamesPlayed++;
            updateGamesPlayedText();

            if (!intervalPool.isEmpty()) {
                intervalPool.remove(0);
            }
            handler.postDelayed(this::playRandomInterval, 1000);
        } else {
            mistakesCount++;
            showFeedback("Wrong! Correct: " + correctInterval, false);
        }
    }

    private void checkChordAnswer() {
        if (isChordAnswered) return;

        String selectedChord = chordsSpinner.getSelectedItem().toString();
        boolean isCorrect = selectedChord.equals(chordType);

        if (isCorrect) {
            showFeedbackChords("Correct!", true);
            correctAnswers++;
        } else {
            mistakesCount++;
            showFeedbackChords("Wrong! Correct: " + chordType, false);
        }

        isChordAnswered = true;
        gamesPlayed++;
        updateGamesPlayedText();
    }

    private String calculateInterval(String first, String second) {
        first = first.replace("sharp", "#");
        second = second.replace("sharp", "#");

        String[] allNotes = {
                "c3", "c#3", "d3", "d#3", "e3", "f3", "f#3", "g3", "g#3", "a3", "a#3", "b3",
                "c4", "c#4", "d4", "d#4", "e4", "f4", "f#4", "g4", "g#4", "a4", "a#4", "b4",
                "c5", "c#5", "d5", "d#5", "e5", "f5", "f#5", "g5", "g#5", "a5", "a#5", "b5"
        };

        int firstIndex = -1, secondIndex = -1;

        for (int i = 0; i < allNotes.length; i++) {
            if (allNotes[i].equals(first)) firstIndex = i;
            if (allNotes[i].equals(second)) secondIndex = i;
        }

        if (firstIndex == -1 || secondIndex == -1) return "Unknown";

        int distance = Math.abs(secondIndex - firstIndex);

        switch (distance) {
            case 0: return "Unison";
            case 1: return "Minor second";
            case 2: return "Major second";
            case 3: return "Minor third";
            case 4: return "Major third";
            case 5: return "Perfect fourth";
            case 6: return "Tritone";
            case 7: return "Perfect fifth";
            case 8: return "Minor sixth";
            case 9: return "Major sixth";
            case 10: return "Minor seventh";
            case 11: return "Major seventh";
            case 12: return "Octave";
            default: return "Unknown";
        }
    }

    private void displayCorrectChord() {
        String chordString = formatChordNotes(currentChordNotes);

        if (chordNotesLabel != null) {
            chordNotesLabel.setText(chordString);
            chordNotesLabel.setVisibility(View.VISIBLE);
            handler.postDelayed(() -> chordNotesLabel.setVisibility(View.INVISIBLE), 1500);
        }
    }
}