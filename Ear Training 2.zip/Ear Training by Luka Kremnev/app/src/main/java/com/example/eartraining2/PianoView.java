package com.example.eartraining2;

import android.content.Context;
import android.media.MediaPlayer;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.LinearLayout;

public class PianoView extends LinearLayout {

    private MediaPlayer mediaPlayer;

    public PianoView(Context context, AttributeSet attrs) {
        super(context, attrs);
        inflate(context, R.layout.piano_view, this);
        setupKeys();
    }

    private void setupKeys() {
        setKeySound(R.id.c_4, R.raw.c4);
        setKeySound(R.id.c_sharp_4, R.raw.csharp4);
        setKeySound(R.id.d_4, R.raw.d4);
        setKeySound(R.id.d_sharp_4, R.raw.dsharp4);
        setKeySound(R.id.e_4, R.raw.e4);
        setKeySound(R.id.f_4, R.raw.f4);
        setKeySound(R.id.f_sharp_4, R.raw.fsharp4);
        setKeySound(R.id.g_4, R.raw.g4);
        setKeySound(R.id.g_sharp_4, R.raw.gsharp4);
        setKeySound(R.id.a_4, R.raw.a4);
        setKeySound(R.id.a_sharp_4, R.raw.asharp4);
        setKeySound(R.id.b_4, R.raw.b4);
    }

    private void setKeySound(int buttonId, int soundId) {
        Button key = findViewById(buttonId);
        key.setOnClickListener(v -> playSound(soundId));
    }

    private void playSound(int soundId) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(getContext(), soundId);
        mediaPlayer.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}