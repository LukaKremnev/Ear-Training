package com.example.eartraining2;

import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.HashMap;
import java.util.Map;

public class StatisticsActivity extends AppCompatActivity {

    private TextView numberOfStars, totalPlays;
    private TextView easyGames, mediumGames, hardGames;
    private TextView notesGames, intervalsGames, chordsGames;
    private Button resetButton;
    private Button homeButton, statisticsButton, settingsButton;

    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private DocumentReference statsRef;
    private ListenerRegistration statsListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistics);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        FirebaseUser user = auth.getCurrentUser();
        if (user == null) return;

        statsRef = db.collection("statistics").document(user.getUid());

        numberOfStars = findViewById(R.id.number_of_stars);
        totalPlays = findViewById(R.id.total_plays);

        easyGames = findViewById(R.id.easy_games);
        mediumGames = findViewById(R.id.medium_games);
        hardGames = findViewById(R.id.hard_games);

        notesGames = findViewById(R.id.notes_games);
        intervalsGames = findViewById(R.id.intervals_games);
        chordsGames = findViewById(R.id.chords_games);

        resetButton = findViewById(R.id.reset_statistics_button);
        homeButton = findViewById(R.id.home_button);
        statisticsButton = findViewById(R.id.statistics_button);
        settingsButton = findViewById(R.id.settings_button);
        statisticsButton.setEnabled(false);

        loadStatistics();
        setupNavigation();

        resetButton.setOnClickListener(v -> showResetDialog());
    }

    private void loadStatistics() {
        statsListener = statsRef.addSnapshotListener((snapshot, e) -> {
            if (snapshot != null && snapshot.exists()) {

                long stars = snapshot.getLong("stars") != null ? snapshot.getLong("stars") : 0;
                long total = snapshot.getLong("totalPlays") != null ? snapshot.getLong("totalPlays") : 0;
                numberOfStars.setText("Number of Stars: " + stars);
                totalPlays.setText("Total Plays: " + total);

                long easyGamesCount = snapshot.getLong("easyGames") != null ? snapshot.getLong("easyGames") : 0;
                long easyRate = snapshot.getLong("easyRate") != null ? snapshot.getLong("easyRate") : 0;
                if (easyGamesCount > 0)
                    easyGames.setText("Easy Games: " + easyGamesCount + " games (" + easyRate + "% success rate)");
                else
                    easyGames.setText("Easy Games: 0 games");

                long mediumGamesCount = snapshot.getLong("mediumGames") != null ? snapshot.getLong("mediumGames") : 0;
                long mediumRate = snapshot.getLong("mediumRate") != null ? snapshot.getLong("mediumRate") : 0;
                if (mediumGamesCount > 0)
                    mediumGames.setText("Medium Games: " + mediumGamesCount + " games (" + mediumRate + "% success rate)");
                else
                    mediumGames.setText("Medium Games: 0 games");

                long hardGamesCount = snapshot.getLong("hardGames") != null ? snapshot.getLong("hardGames") : 0;
                long hardRate = snapshot.getLong("hardRate") != null ? snapshot.getLong("hardRate") : 0;
                if (hardGamesCount > 0)
                    hardGames.setText("Hard Games: " + hardGamesCount + " games (" + hardRate + "% success rate)");
                else
                    hardGames.setText("Hard Games: 0 games");

                long notesCount = snapshot.getLong("notesGames") != null ? snapshot.getLong("notesGames") : 0;
                String notesStars = snapshot.getString("notesStars") != null ? snapshot.getString("notesStars") : "☆☆☆";
                if (notesCount > 0)
                    notesGames.setText("Notes: " + notesCount + " games (Average Stars: " + notesStars + ")");
                else
                    notesGames.setText("Notes: 0 games");

                long intervalsCount = snapshot.getLong("intervalsGames") != null ? snapshot.getLong("intervalsGames") : 0;
                String intervalsStars = snapshot.getString("intervalsStars") != null ? snapshot.getString("intervalsStars") : "☆☆☆";
                if (intervalsCount > 0)
                    intervalsGames.setText("Intervals: " + intervalsCount + " games (Average Stars: " + intervalsStars + ")");
                else
                    intervalsGames.setText("Intervals: 0 games");

                long chordsCount = snapshot.getLong("chordsGames") != null ? snapshot.getLong("chordsGames") : 0;
                String chordsStars = snapshot.getString("chordsStars") != null ? snapshot.getString("chordsStars") : "☆☆☆";
                if (chordsCount > 0)
                    chordsGames.setText("Chords: " + chordsCount + " games (Average Stars: " + chordsStars + ")");
                else
                    chordsGames.setText("Chords: 0 games");
            }
        });
    }

    private void showResetDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Reset All Statistics")
                .setMessage("Do you really want to reset all your progress? This action cannot be undone.")
                .setPositiveButton("Yes", (dialogInterface, which) -> resetStatistics())
                .setNegativeButton("Cancel", (dialogInterface, which) -> dialogInterface.dismiss())
                .setCancelable(false)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);

            int container = getThemeColor(com.google.android.material.R.attr.colorContainer);
            int onPrimary = getThemeColor(com.google.android.material.R.attr.colorOnPrimary);
            int onSurface = getThemeColor(com.google.android.material.R.attr.colorOnSurface);

            positiveButton.setTextColor(onSurface);
            positiveButton.setBackgroundColor(container);
            negativeButton.setTextColor(onPrimary);
            negativeButton.setBackgroundColor(onSurface);
        });

        dialog.show();
    }

    private void resetStatistics() {
        Map<String, Object> resetData = new HashMap<>();
        resetData.put("stars", 0);
        resetData.put("totalPlays", 0);

        resetData.put("easyGames", 0);
        resetData.put("easyRate", 0);
        resetData.put("mediumGames", 0);
        resetData.put("mediumRate", 0);
        resetData.put("hardGames", 0);
        resetData.put("hardRate", 0);

        resetData.put("notesGames", 0);
        resetData.put("notesStars", "☆☆☆");
        resetData.put("intervalsGames", 0);
        resetData.put("intervalsStars", "☆☆☆");
        resetData.put("chordsGames", 0);
        resetData.put("chordsStars", "☆☆☆");

        statsRef.set(resetData).addOnSuccessListener(aVoid ->
                Toast.makeText(this, "Statistics reset.", Toast.LENGTH_SHORT).show()
        );
    }

    private void setupNavigation() {
        homeButton.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        settingsButton.setOnClickListener(v -> {
            startActivity(new Intent(this, SettingsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });
    }

    private int getThemeColor(int attr) {
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(attr, typedValue, true);
        return typedValue.data;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (statsListener != null) statsListener.remove();
    }
}