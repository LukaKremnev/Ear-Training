package com.example.eartraining2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;

public class SoloPauseActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.solo_pause);

        Button continueButton = findViewById(R.id.continue_button);
        Button exitButton = findViewById(R.id.exit_button);
        Button tryagainButton = findViewById(R.id.try_again_button);

        continueButton.setOnClickListener(v -> finish());

        exitButton.setOnClickListener(v -> {
            AlertDialog dialog = new AlertDialog.Builder(SoloPauseActivity.this)
                    .setTitle("Are you sure?")
                    .setMessage("Your progress will not be saved.")
                    .setPositiveButton("Exit", (dialogInterface, which) -> {
                        Intent intent = new Intent(SoloPauseActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        finish();
                    })
                    .setNegativeButton("Cancel", null)
                    .setCancelable(true)
                    .create();

            dialog.setOnShowListener(dialogInterface -> {
                Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
                Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);

                int container = getThemeColor(com.google.android.material.R.attr.colorContainer);
                int onPrimary = getThemeColor(com.google.android.material.R.attr.colorOnPrimary);
                int onSurface = getThemeColor(com.google.android.material.R.attr.colorOnSurface);

                positiveButton.setTextColor(onSurface);
                positiveButton.setBackgroundColor(container);
                positiveButton.setAllCaps(true);
                positiveButton.setPadding(32, 12, 32, 12);

                negativeButton.setTextColor(onPrimary);
                negativeButton.setTypeface(null, android.graphics.Typeface.BOLD);
                negativeButton.setAllCaps(true);
                negativeButton.setBackgroundColor(android.graphics.Color.TRANSPARENT);
            });

            dialog.show();
        });

        tryagainButton.setOnClickListener(v -> {
            Intent receivedIntent = getIntent();

            String mode = receivedIntent.getStringExtra("selectedMode");
            String difficulty = receivedIntent.getStringExtra("selectedDifficulty");
            String testSize = receivedIntent.getStringExtra("selectedTestSize");

            getSharedPreferences("game_state", MODE_PRIVATE).edit().clear().apply();

            Intent retryIntent = new Intent(SoloPauseActivity.this, SoloPlayActivity.class);
            retryIntent.putExtra("selectedMode", mode);
            retryIntent.putExtra("selectedDifficulty", difficulty);
            retryIntent.putExtra("selectedTestSize", testSize);

            startActivity(retryIntent);
            finish();
        });
    }

    private int getThemeColor(int attr) {
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(attr, typedValue, true);
        return typedValue.data;
    }
}