package com.example.eartraining2;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SettingsActivity extends AppCompatActivity {

    private TextView nicknameText, idText;
    private Button loginLogoutButton, supportButton;
    private SwitchMaterial darkThemeSwitch;
    private SharedPreferences preferences;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        preferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        boolean isDarkMode = preferences.getBoolean("dark_theme", false);
        AppCompatDelegate.setDefaultNightMode(
                isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
        );

        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        nicknameText = findViewById(R.id.nickname_value);
        idText = findViewById(R.id.id_value);
        darkThemeSwitch = findViewById(R.id.dark_theme_switch);
        loginLogoutButton = findViewById(R.id.register_login_button);
        supportButton = findViewById(R.id.support_button);

        updateUserInfo();

        darkThemeSwitch.setChecked(isDarkMode);
        darkThemeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            applyTheme(isChecked);
        });

        loginLogoutButton.setOnClickListener(v -> {
            FirebaseUser user = auth.getCurrentUser();
            if (user != null) {
                showLogoutDialog();
            } else {
                startActivity(new Intent(SettingsActivity.this, RegisterActivity.class));
                overridePendingTransition(0, 0);
            }
        });

        supportButton.setOnClickListener(v -> openGmailSupport());

        setupNavigation();
    }

    @SuppressLint("WrongConstant")
    private void applyTheme(boolean isDarkMode) {
        preferences.edit().putBoolean("dark_theme", isDarkMode).apply();
        AppCompatDelegate.setDefaultNightMode(
                isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
        );
        recreate();
    }

    private void updateUserInfo() {
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            db.collection("users").document(user.getUid()).get()
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful() && task.getResult() != null) {
                            DocumentSnapshot documentSnapshot = task.getResult();
                            if (documentSnapshot.exists()) {
                                String username = documentSnapshot.getString("username");
                                String shortId = documentSnapshot.getString("uniqueId");

                                nicknameText.setText(username != null ? username : "Unknown");
                                idText.setText(shortId != null ? shortId : "No ID");
                            } else {
                                nicknameText.setText("Unknown");
                                idText.setText("No ID");
                            }
                        } else {
                            nicknameText.setText("Unknown");
                            idText.setText("No ID");
                        }
                    });

            loginLogoutButton.setText("Sign Out");
        } else {
            nicknameText.setText("Guest");
            idText.setText("Not Logged In");
            loginLogoutButton.setText("Sign In / Login");
        }
    }

    private void openGmailSupport() {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"kremnevl.isr@gmail.com"});
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Support Request - Ear Training App");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "Hello,\n\nI need help with the Ear Training app.\n\nBest regards,\n");

        try {
            startActivity(Intent.createChooser(emailIntent, "Send email via..."));
        } catch (Exception e) {
            Toast.makeText(SettingsActivity.this, "No email app found.", Toast.LENGTH_SHORT).show();
        }
    }

    private void setupNavigation() {
        findViewById(R.id.home_button).setOnClickListener(v -> {
            startActivity(new Intent(SettingsActivity.this, MainActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        findViewById(R.id.statistics_button).setOnClickListener(v -> {
            startActivity(new Intent(SettingsActivity.this, StatisticsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        findViewById(R.id.settings_button).setEnabled(false);
    }

    // Метод получения цвета из темы
    private int getThemeColor(int attr) {
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(attr, typedValue, true);
        return typedValue.data;
    }

    private void showLogoutDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Logout from account")
                .setMessage("Do you want to log out?")
                .setPositiveButton("Yes", (dialogInterface, which) -> {
                    auth.signOut();
                    showSuccessDialog("Complete!", "You have successfully logged out of your account.");
                })
                .setNegativeButton("Cancel", (dialogInterface, which) -> dialogInterface.dismiss())
                .setCancelable(false)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);

            int container = getThemeColor(com.google.android.material.R.attr.colorContainer);
            int onPrimary = getThemeColor(com.google.android.material.R.attr.colorOnPrimary);
            int onSurface = getThemeColor(com.google.android.material.R.attr.colorOnSurface);


            positiveButton.setTextColor(onSurface);
            positiveButton.setBackgroundColor(container);
            negativeButton.setTextColor(onPrimary);
            negativeButton.setBackgroundColor(onSurface);
        });

        dialog.show();
    }

    private void showSuccessDialog(String title, String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("Оk", (dialogInterface, which) -> updateUserInfo())
                .setCancelable(false)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            int container = getThemeColor(com.google.android.material.R.attr.colorContainer);
            int onSurface = getThemeColor(com.google.android.material.R.attr.colorOnSurface);

            positiveButton.setTextColor(onSurface);
            positiveButton.setBackgroundColor(container);
        });

        dialog.show();
    }
}