package com.example.eartraining2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private Button homeButton, statisticsButton, settingsButton;
    private FirebaseAuth auth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.Theme_EarTraining2);
        FirebaseApp.initializeApp(this);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            FirebaseAuth.getInstance().signInAnonymously()
                    .addOnSuccessListener(result -> Log.d("AUTH", "Anonymous login successful"))
                    .addOnFailureListener(e -> Log.e("AUTH", "Anonymous login failed", e));
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();

        homeButton = findViewById(R.id.home_button);
        statisticsButton = findViewById(R.id.statistics_button);
        settingsButton = findViewById(R.id.settings_button);

        setupNavigation();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.mode_interface, new SoloModeFragment())
                .commit();
    }

    private void setupNavigation() {
        findViewById(R.id.home_button).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, MainActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        findViewById(R.id.statistics_button).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, StatisticsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        findViewById(R.id.settings_button).setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }
}