package com.example.eartraining2;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {

    private EditText emailInput, passwordInput;
    private Button loginButton, registerButton;
    private Button homeButton, statisticsButton, settingsButton;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        registerButton = findViewById(R.id.register_button);

        homeButton = findViewById(R.id.home_button);
        statisticsButton = findViewById(R.id.statistics_button);
        settingsButton = findViewById(R.id.settings_button);

        setupNavigation();

        registerButton.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            finish();
            overridePendingTransition(0, 0);
        });

        loginButton.setOnClickListener(v -> loginUser());
    }

    private void setupNavigation() {
        homeButton.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, MainActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        statisticsButton.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, StatisticsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        settingsButton.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, SettingsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });
    }

    private void loginUser() {
        String input = emailInput.getText().toString().trim(); // Это может быть ник или email
        String password = passwordInput.getText().toString().trim();

        if (TextUtils.isEmpty(input)) {
            emailInput.setError("Enter Email or Nickname");
            emailInput.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            passwordInput.setError("Enter Password");
            passwordInput.requestFocus();
            return;
        }

        if (android.util.Patterns.EMAIL_ADDRESS.matcher(input).matches()) {
            signInWithEmail(input, password);
        } else {
            findEmailByUsername(input, password);
        }
    }

    private void signInWithEmail(String email, String password) {
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = auth.getCurrentUser();
                        if (user != null) {
                            fetchAndSaveUsername(user.getUid());
                        }
                    } else {
                        handleLoginError(task.getException());
                    }
                });
    }

    private void findEmailByUsername(String username, String password) {
        db.collection("users")
                .whereEqualTo("username", username)
                .limit(1) // Берём только одного пользователя
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    if (!querySnapshot.isEmpty()) {
                        DocumentSnapshot userDoc = querySnapshot.getDocuments().get(0);
                        String email = userDoc.getString("email");
                        if (email != null) {
                            signInWithEmail(email, password); // Входим через email
                        } else {
                            emailInput.setError("Email not found for this nickname");
                        }
                    } else {
                        emailInput.setError("User with this nickname not found");
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(LoginActivity.this, "Request error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void handleLoginError(Exception e) {
        if (e != null) {
            try {
                throw e;
            } catch (FirebaseAuthInvalidUserException ex) {
                emailInput.setError("User not found");
                emailInput.requestFocus();
            } catch (FirebaseAuthInvalidCredentialsException ex) {
                passwordInput.setError("Incorrect password");
                passwordInput.requestFocus();
            } catch (Exception ex) {
                Toast.makeText(LoginActivity.this, "Error: " + ex.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void fetchAndSaveUsername(String userId) {
        db.collection("users").document(userId).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String username = documentSnapshot.getString("username");
                        showSuccessDialog(username);
                    } else {
                        showSuccessDialog("user");
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(LoginActivity.this, "Error loading nickname", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    finish();
                });
    }

    private void showSuccessDialog(String username) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Successful login!")
                .setMessage("Welcome, " + username + "!")
                .setPositiveButton("Continue", (dialogInterface, which) -> {
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    finish();
                })
                .setCancelable(false)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

            int container = getThemeColor(com.google.android.material.R.attr.colorContainer);
            int onSurface = getThemeColor(com.google.android.material.R.attr.colorOnSurface);

            positiveButton.setTextColor(onSurface);
            positiveButton.setBackgroundColor(container);
        });

        dialog.show();
    }

    private int getThemeColor(int attr) {
        TypedValue typedValue = new TypedValue();
        getTheme().resolveAttribute(attr, typedValue, true);
        return typedValue.data;
    }
}