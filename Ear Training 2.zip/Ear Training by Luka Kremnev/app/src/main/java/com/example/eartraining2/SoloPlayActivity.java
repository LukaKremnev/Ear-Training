package com.example.eartraining2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;

public class SoloPlayActivity extends AppCompatActivity {

    private Button pauseButton, playNoteButton, playCNoteButton;
    private TextView remainingGamesText, selectedModeText, selectedDifficultyText, answerFeedbackText;
    private FrameLayout soloGameInterface;
    private MediaPlayer mediaPlayer;
    private int remainingGames;
    private int mistakesCount = 0;
    private String selectedMode, selectedDifficulty, selectedTestSize;
    private ArrayList<String> notesPool;
    private String currentNote;
    private boolean isNoteAnswered = true;
    private final Handler handler = new Handler();
    private Button playIntervalButton, answerButton;
    private TextView answerFeedbackTextIntervals;
    private ArrayList<String> intervalPool;
    private String firstNote, secondNote;
    private String[] intervalNames = {
            "Unison", "Minor second", "Major second", "Minor third", "Major third",
            "Perfect fourth", "Tritone", "Perfect fifth", "Minor sixth", "Major sixth",
            "Minor seventh", "Major seventh", "Octave"
    };
    private Button playChordButton, answerChordButton, displayChordButton;
    private TextView answerFeedbackTextChords;
    private Spinner chordsSpinner;
    private ArrayList<String> chordPool;
    private String[] allNotes = {
            "c3", "csharp3", "d3", "dsharp3", "e3", "f3", "fsharp3", "g3", "gsharp3", "a3", "asharp3", "b3",
            "c4", "csharp4", "d4", "dsharp4", "e4", "f4", "fsharp4", "g4", "gsharp4", "a4", "asharp4", "b4",
            "c5", "csharp5", "d5", "dsharp5", "e5", "f5", "fsharp5", "g5", "gsharp5", "a5", "asharp5", "b5"
    };
    private String rootNote, chordType;
    private ArrayList<String> currentChordNotes;
    private boolean isChordAnswered = true; // Теперь аккорд не меняется, пока не ответишь
    private TextView chordNotesLabel;
    private int correctAnswers = 0;
    private SoundManager soundManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        selectedMode = intent.getStringExtra("selectedMode");
        selectedDifficulty = intent.getStringExtra("selectedDifficulty");
        selectedTestSize = intent.getStringExtra("selectedTestSize");

        if ("Endless".equals(selectedTestSize)) {
            Intent endlessIntent = new Intent(this, EndlessSoloPlayActivity.class);
            endlessIntent.putExtra("selectedMode", selectedMode);
            endlessIntent.putExtra("selectedDifficulty", selectedDifficulty);
            endlessIntent.putExtra("selectedTestSize", selectedTestSize); // ✅ Добавляем параметр
            startActivity(endlessIntent);
            finish();
            return;
        }

        setContentView(R.layout.solo_play);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        try {
            remainingGames = Integer.parseInt(selectedTestSize);
        } catch (NumberFormatException e) {
            remainingGames = 10;
        }

        pauseButton = findViewById(R.id.pause_button);
        remainingGamesText = findViewById(R.id.remaining_games);
        selectedModeText = findViewById(R.id.selected_mode);
        selectedDifficultyText = findViewById(R.id.selected_difficulty);
        soloGameInterface = findViewById(R.id.solo_game_interface);

        selectedModeText.setText("Mode: " + selectedMode);
        selectedDifficultyText.setText("Difficulty: " + selectedDifficulty);
        updateRemainingGamesText();

        loadGameInterface(selectedMode);

        pauseButton.setOnClickListener(v -> pauseGame());

        soundManager = new SoundManager(this);

        for (String note : allNotes) {
            soundManager.loadSound(note);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveGameState();
    }

    private void saveGameState() {
        getSharedPreferences("game_state", MODE_PRIVATE).edit()
                .putString("mode", selectedMode)
                .putString("difficulty", selectedDifficulty)
                .putString("testSize", selectedTestSize)
                .putInt("remainingGames", remainingGames)
                .putInt("mistakesCount", mistakesCount)
                .putInt("correctAnswers", correctAnswers)
                .putString("currentNote", currentNote)
                .putBoolean("isNoteAnswered", isNoteAnswered)
                .putString("firstNote", firstNote)
                .putString("secondNote", secondNote)
                .putString("currentChordNotes", String.join(",", currentChordNotes != null ? currentChordNotes : new ArrayList<>()))
                .putString("chordType", chordType)
                .putString("rootNote", rootNote)
                .putBoolean("isChordAnswered", isChordAnswered)
                .apply();
    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        boolean fromPause = intent.getBooleanExtra("pause", false);

        if (fromPause) {
            restoreGameState();
        }
    }

    private void restoreGameState() {
        SharedPreferences prefs = getSharedPreferences("game_state", MODE_PRIVATE);
        selectedMode = prefs.getString("mode", selectedMode);
        selectedDifficulty = prefs.getString("difficulty", selectedDifficulty);
        selectedTestSize = prefs.getString("testSize", selectedTestSize);
        remainingGames = prefs.getInt("remainingGames", remainingGames);
        mistakesCount = prefs.getInt("mistakesCount", 0);
        correctAnswers = prefs.getInt("correctAnswers", 0);
        currentNote = prefs.getString("currentNote", null);
        isNoteAnswered = prefs.getBoolean("isNoteAnswered", true);
        firstNote = prefs.getString("firstNote", null);
        secondNote = prefs.getString("secondNote", null);
        rootNote = prefs.getString("rootNote", null);
        chordType = prefs.getString("chordType", null);
        isChordAnswered = prefs.getBoolean("isChordAnswered", true);

        String savedChord = prefs.getString("currentChordNotes", "");
        currentChordNotes = new ArrayList<>();
        if (!savedChord.isEmpty()) {
            Collections.addAll(currentChordNotes, savedChord.split(","));
        }
    }

    private void pauseGame() {
        Intent intent = new Intent(this, SoloPauseActivity.class);
        intent.putExtra("selectedMode", selectedMode);
        intent.putExtra("selectedDifficulty", selectedDifficulty);
        intent.putExtra("selectedTestSize", selectedTestSize);
        intent.putExtra("pause", true);
        startActivity(intent);
    }

    private void updateRemainingGamesText() {
        remainingGamesText.setText("Remaining Games: " + remainingGames);
    }

    private void loadGameInterface(String mode) {
        int layoutId;

        if (mode.equals("Notes")) {
            layoutId = R.layout.notes_solo_game_interface;
        } else if (mode.equals("Intervals")) {
            layoutId = R.layout.intervals_solo_game_interface;
        } else if (mode.equals("Chords")) {
            layoutId = R.layout.chords_solo_game_interface;
        } else {
            return;
        }

        View gameView = LayoutInflater.from(this).inflate(layoutId, soloGameInterface, false);
        soloGameInterface.removeAllViews();
        soloGameInterface.addView(gameView);

        if (mode.equals("Notes")) {
            setupNotesGame(gameView);
        } else if (mode.equals("Intervals")) {
            setupIntervalsGame(gameView);
        } else if (mode.equals("Chords")) {
            setupChordsGame(gameView);
        }
    }

    private void setupNotesGame(View gameView) {
        playNoteButton = gameView.findViewById(R.id.play_note_button);
        playCNoteButton = gameView.findViewById(R.id.play_c_note_button);
        answerFeedbackText = gameView.findViewById(R.id.answer_feedback_text);

        generateNotesPool();

        playNoteButton.setOnClickListener(v -> {
            if (isNoteAnswered) {
                playRandomNote();
                isNoteAnswered = false;
            } else {
                repeatCurrentNote();
            }
        });

        if (playCNoteButton != null) {
            playCNoteButton.setOnClickListener(v -> playNoteSound("c4"));
        }

        setupPianoKeys(gameView);
    }

    private void setupIntervalsGame(View gameView) {
        playIntervalButton = gameView.findViewById(R.id.play_interval_button);
        answerButton = gameView.findViewById(R.id.answer_button);
        answerFeedbackTextIntervals = gameView.findViewById(R.id.answer_feedback_text);
        Spinner intervalSpinner = gameView.findViewById(R.id.intervals_spinner);

        if (playIntervalButton == null || answerButton == null || intervalSpinner == null) {
            Log.e("SoloPlayActivity", "setupIntervalsGame: One or more UI elements are null!");
            return;
        }

        ArrayList<String> availableIntervals = new ArrayList<>();

        if (selectedDifficulty.equals("Easy")) {
            availableIntervals.add("Unison");
            availableIntervals.add("Minor second");
            availableIntervals.add("Major second");
            availableIntervals.add("Minor third");
            availableIntervals.add("Major third");
            availableIntervals.add("Perfect fourth");
            availableIntervals.add("Perfect fifth");
        } else if (selectedDifficulty.equals("Medium")) {
            availableIntervals.add("Unison");
            availableIntervals.add("Minor second");
            availableIntervals.add("Major second");
            availableIntervals.add("Minor third");
            availableIntervals.add("Major third");
            availableIntervals.add("Perfect fourth");
            availableIntervals.add("Perfect fifth");
            availableIntervals.add("Minor sixth");
            availableIntervals.add("Major sixth");
            availableIntervals.add("Minor seventh");
            availableIntervals.add("Major seventh");
        } else { // Hard
            Collections.addAll(availableIntervals, intervalNames);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, availableIntervals);
        intervalSpinner.setAdapter(adapter);

        generateIntervalPool();

        playIntervalButton.setOnClickListener(v -> playRandomInterval());
        answerButton.setOnClickListener(v -> checkIntervalAnswer());
    }

    private void setupChordsGame(View gameView) {
        playChordButton = gameView.findViewById(R.id.play_chord_button);
        answerChordButton = gameView.findViewById(R.id.check_chord_button);
        displayChordButton = gameView.findViewById(R.id.display_chord_button);
        answerFeedbackTextChords = gameView.findViewById(R.id.answer_feedback_text);
        chordNotesLabel = gameView.findViewById(R.id.chord_notes_label);
        chordsSpinner = gameView.findViewById(R.id.chords_spinner);

        if (playChordButton == null || answerChordButton == null || displayChordButton == null || chordsSpinner == null) {
            Log.e("SoloPlayActivity", "setupChordsGame: One or more UI elements are null!");
            return;
        }

        ArrayList<String> availableChords = new ArrayList<>();
        if (selectedDifficulty.equals("Easy")) {
            Collections.addAll(availableChords, "Major", "Minor", "Diminished", "Augmented");
        } else if (selectedDifficulty.equals("Medium")) {
            Collections.addAll(availableChords, "Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th");
        } else { // Hard
            Collections.addAll(availableChords, "Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th",
                    "Sixth", "Ninth", "Eleventh", "Thirteenth");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, availableChords);
        chordsSpinner.setAdapter(adapter);

        generateChordPool();

        playChordButton.setOnClickListener(v -> playRandomChord());
        answerChordButton.setOnClickListener(v -> checkChordAnswer());
        displayChordButton.setOnClickListener(v -> displayCorrectChord());
    }

    private void generateNotesPool() {
        String[] baseNotes = {"c", "csharp", "d", "dsharp", "e", "f", "fsharp", "g", "gsharp", "a", "asharp", "b"};
        HashSet<String> uniqueNotes = new HashSet<>();

        int[] octaves = selectedDifficulty.equals("Easy") ? new int[]{4} :
                selectedDifficulty.equals("Medium") ? new int[]{3, 4} :
                        new int[]{3, 4, 5};

        while (uniqueNotes.size() < remainingGames) {
            String note = baseNotes[new Random().nextInt(baseNotes.length)] + octaves[new Random().nextInt(octaves.length)];
            uniqueNotes.add(note);
        }

        notesPool = new ArrayList<>(uniqueNotes);
        Collections.shuffle(notesPool);
    }

    private void generateIntervalPool() {
        String[] allNotes = {
                "c3", "csharp3", "d3", "dsharp3", "e3", "f3", "fsharp3", "g3", "gsharp3", "a3", "asharp3", "b3",
                "c4", "csharp4", "d4", "dsharp4", "e4", "f4", "fsharp4", "g4", "gsharp4", "a4", "asharp4", "b4",
                "c5", "csharp5", "d5", "dsharp5", "e5", "f5", "fsharp5", "g5", "gsharp5", "a5", "asharp5", "b5"
        };

        HashSet<String> uniqueIntervals = new HashSet<>();
        Random random = new Random();

        ArrayList<Integer> availableDistances = new ArrayList<>();

        if (selectedDifficulty.equals("Easy")) {
            Collections.addAll(availableDistances, 0, 1, 2, 3, 4, 5, 7); // Unison, Minor/Major second, Minor/Major third, Perfect fourth/fifth
        } else if (selectedDifficulty.equals("Medium")) {
            Collections.addAll(availableDistances, 0, 1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12); // + Minor/Major sixth, Minor/Major seventh, Octave
        } else { // Hard
            Collections.addAll(availableDistances, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12); // + Tritone
        }

        while (uniqueIntervals.size() < remainingGames) {
            int firstIndex = random.nextInt(allNotes.length - 12);
            int distance = availableDistances.get(random.nextInt(availableDistances.size()));
            int secondIndex = firstIndex + distance;

            if (secondIndex >= allNotes.length) continue;

            String firstNote = allNotes[firstIndex];
            String secondNote = allNotes[secondIndex];

            uniqueIntervals.add(firstNote + "_" + secondNote);
        }

        intervalPool = new ArrayList<>(uniqueIntervals);
        Collections.shuffle(intervalPool);
    }

    private void generateChordPool() {
        chordPool = new ArrayList<>();
        Random random = new Random();

        String[] allChordTypes;
        if (selectedDifficulty.equals("Easy")) {
            allChordTypes = new String[]{"Major", "Minor", "Diminished", "Augmented"};
        } else if (selectedDifficulty.equals("Medium")) {
            allChordTypes = new String[]{"Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th"};
        } else {
            allChordTypes = new String[]{"Major", "Minor", "Diminished", "Augmented",
                    "Dominant 7th", "Major 7th", "Minor 7th", "Diminished 7th",
                    "Sixth", "Ninth", "Eleventh", "Thirteenth"};
        }

        for (String chord : allChordTypes) {
            int randomNoteIndex = random.nextInt(allNotes.length - 12);
            String root = allNotes[randomNoteIndex];
            chordPool.add(root + "_" + chord);
        }

        Collections.shuffle(chordPool);
    }

    private ArrayList<String> generateChordNotes(String root, String chordType) {
        int rootIndex = -1;
        for (int i = 0; i < allNotes.length; i++) {
            if (allNotes[i].equals(root)) {
                rootIndex = i;
                break;
            }
        }

        if (rootIndex == -1) return new ArrayList<>();

        ArrayList<String> chordNotes = new ArrayList<>();
        chordNotes.add(allNotes[rootIndex]);

        switch (chordType) {
            case "Major":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                break;
            case "Minor":
                chordNotes.add(allNotes[rootIndex + 3]); // m3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                break;
            case "Diminished":
                chordNotes.add(allNotes[rootIndex + 3]); // m3
                chordNotes.add(allNotes[rootIndex + 6]); // dim5
                break;
            case "Augmented":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 8]); // aug5
                break;
            case "Dominant 7th":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                chordNotes.add(allNotes[rootIndex + 10]); // m7
                break;
            case "Major 7th":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                chordNotes.add(allNotes[rootIndex + 11]); // M7
                break;
            case "Minor 7th":
                chordNotes.add(allNotes[rootIndex + 3]); // m3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                chordNotes.add(allNotes[rootIndex + 10]); // m7
                break;
            case "Diminished 7th":
                chordNotes.add(allNotes[rootIndex + 3]); // m3
                chordNotes.add(allNotes[rootIndex + 6]); // dim5
                chordNotes.add(allNotes[rootIndex + 9]); // dim7
                break;
            case "Sixth":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                chordNotes.add(allNotes[rootIndex + 9]); // M6
                break;
            case "Ninth":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                chordNotes.add(allNotes[rootIndex + 10]); // m7
                chordNotes.add(allNotes[rootIndex + 14]); // M9
                break;
            case "Eleventh":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                chordNotes.add(allNotes[rootIndex + 10]); // m7
                chordNotes.add(allNotes[rootIndex + 14]); // M9
                chordNotes.add(allNotes[rootIndex + 17]); // P11
                break;
            case "Thirteenth":
                chordNotes.add(allNotes[rootIndex + 4]); // M3
                chordNotes.add(allNotes[rootIndex + 7]); // P5
                chordNotes.add(allNotes[rootIndex + 10]); // m7
                chordNotes.add(allNotes[rootIndex + 14]); // M9
                chordNotes.add(allNotes[rootIndex + 17]); // P11
                chordNotes.add(allNotes[rootIndex + 21]); // M13
                break;
        }

        return chordNotes;
    }

    private void playRandomNote() {
        if (notesPool.isEmpty()) {
            finishSoloGame();
            return;
        }

        currentNote = notesPool.remove(0);
        playNoteSound(currentNote);
    }

    private void playRandomInterval() {
        if (intervalPool.isEmpty()) {
            finishSoloGame();
            return;
        }

        String[] interval = intervalPool.get(0).split("_");
        firstNote = interval[0];
        secondNote = interval[1];

        soundManager.playSound(firstNote);
        new Handler().postDelayed(() -> soundManager.playSound(secondNote), 400);
    }

    private void playRandomChord() {
        if (isChordAnswered) {
            if (chordPool.isEmpty()) {
                generateChordPool();
            }

            String[] chordInfo = chordPool.remove(0).split("_");
            rootNote = chordInfo[0];
            chordType = chordInfo[1];
            currentChordNotes = generateChordNotes(rootNote, chordType);

            isChordAnswered = false;
        }

        playChord(currentChordNotes);
    }

    private void playChord(ArrayList<String> chordNotes) {
        if (chordNotes == null || chordNotes.isEmpty()) return;

        Handler handler = new Handler();
        for (int i = 0; i < chordNotes.size(); i++) {
            String note = chordNotes.get(i);
            int delay = 400 * i;

            handler.postDelayed(() -> soundManager.playSound(note), delay);
        }
    }


    private void repeatCurrentNote() {
        if (currentNote == null) return;
        playNoteSound(currentNote);
    }

    private void showFeedbackChords(String message, boolean correct) {
        if (answerFeedbackTextChords != null) {
            answerFeedbackTextChords.setText(message);
            answerFeedbackTextChords.setTextColor(correct ? 0xFF008800 : 0xFFFF0000);
            answerFeedbackTextChords.setVisibility(View.VISIBLE);

            handler.postDelayed(() -> answerFeedbackTextChords.setVisibility(View.INVISIBLE), 1500);
        }
    }

    private String lastCorrectInterval = "";

    private void checkIntervalAnswer() {
        Spinner intervalSpinner = findViewById(R.id.intervals_spinner);
        String selectedInterval = intervalSpinner.getSelectedItem().toString();

        if (lastCorrectInterval.isEmpty()) {
            lastCorrectInterval = calculateInterval(firstNote, secondNote);
        }

        if (selectedInterval.equals(lastCorrectInterval)) {
            showFeedbackIntervals("Correct!", true);
            correctAnswers++;
            lastCorrectInterval = "";
        } else {
            mistakesCount++;
            if (!lastCorrectInterval.equals("Unknown")) {
                showFeedbackIntervals("Wrong! Correct: " + lastCorrectInterval, false);
            } else {
                showFeedbackIntervals("Wrong!", false);
            }
        }

        if (!intervalPool.isEmpty() && lastCorrectInterval.isEmpty()) {
            intervalPool.remove(0);
            remainingGames--;
            updateRemainingGamesText();
        }

        if (remainingGames <= 0) {
            finishSoloGame();
        } else if (lastCorrectInterval.isEmpty()) {
            firstNote = null;
            secondNote = null;
        }
    }

    private void checkChordAnswer() {
        if (isChordAnswered) return;

        String selectedChord = chordsSpinner.getSelectedItem().toString();
        boolean isCorrect = selectedChord.equals(chordType);

        if (isCorrect) {
            showFeedbackChords("Correct!", true);
            correctAnswers++;
        } else {
            mistakesCount++;
            showFeedbackChords("Wrong! Correct: " + formatChordName(rootNote, chordType), false);
        }

        isChordAnswered = true;
        remainingGames--;
        updateRemainingGamesText();

        if (remainingGames <= 0) {
            finishSoloGame();
        }
    }

    private void displayCorrectChord() {
        String chordString = formatChordNotes(currentChordNotes); // ✅ Только ноты без названия аккорда

        if (chordNotesLabel != null) {
            chordNotesLabel.setText(chordString);
            chordNotesLabel.setVisibility(View.VISIBLE);

            handler.postDelayed(() -> chordNotesLabel.setVisibility(View.INVISIBLE), 1500);
        }
    }

    private void playNoteSound(String note) {
        soundManager.playSound(note);
    }

    private String formatChordName(String root, String type) {
        String formattedRoot = root.replaceAll("[0-9]", ""); // ✅ Удаляем октаву
        formattedRoot = formattedRoot.substring(0, 1).toUpperCase() + formattedRoot.substring(1);
        formattedRoot = formattedRoot.replace("sharp", "#"); // ✅ Смена "sharp" на "#"

        switch (type) {
            case "Major": return formattedRoot;
            case "Minor": return formattedRoot + "m";
            case "Diminished": return formattedRoot + "dim";
            case "Augmented": return formattedRoot + "aug";
            case "Dominant 7th": return formattedRoot + "7";
            case "Major 7th": return formattedRoot + "Maj7";
            case "Minor 7th": return formattedRoot + "m7";
            case "Diminished 7th": return formattedRoot + "dim7";
            case "Sixth": return formattedRoot + "6";
            case "Ninth": return formattedRoot + "9";
            case "Eleventh": return formattedRoot + "11";
            case "Thirteenth": return formattedRoot + "13";
            default: return formattedRoot;
        }
    }

    private String formatChordNotes(ArrayList<String> chordNotes) {
        ArrayList<String> formattedNotes = new ArrayList<>();
        for (String note : chordNotes) {
            String formattedNote = note.replaceAll("[0-9]", ""); // ✅ Удаляем октаву
            formattedNote = formattedNote.substring(0, 1).toUpperCase() + formattedNote.substring(1);
            formattedNote = formattedNote.replace("sharp", "#"); // ✅ Смена "sharp" на "#"
            formattedNotes.add(formattedNote);
        }
        return String.join(" - ", formattedNotes);
    }

    private void finishSoloGame() {
        Intent intent = new Intent(this, FinishedSoloGameActivity.class);
        intent.putExtra("mistakes", mistakesCount);
        intent.putExtra("correctAnswers", correctAnswers);
        intent.putExtra("selectedMode", selectedMode); // ✅ Передача параметров
        intent.putExtra("selectedDifficulty", selectedDifficulty); // ✅ Передача параметров
        intent.putExtra("selectedTestSize", selectedTestSize); // ✅ Передача параметров
        startActivity(intent);

        new Handler().postDelayed(this::finish, 500);
    }

    private void setupPianoKeys(View parentView) {
        int[] whiteKeys = {R.id.c_4, R.id.d_4, R.id.e_4, R.id.f_4, R.id.g_4, R.id.a_4, R.id.b_4};
        int[] blackKeys = {R.id.c_sharp_4, R.id.d_sharp_4, R.id.f_sharp_4, R.id.g_sharp_4, R.id.a_sharp_4};

        View.OnClickListener listener = v -> {
            if (isNoteAnswered) return;

            String pressedNote = getResources().getResourceEntryName(v.getId())
                    .replace("_4", "")
                    .replace("_sharp", "sharp");

            String expectedNote = currentNote.replaceAll("[0-9]", "");

            if (pressedNote.equals(expectedNote)) {
                playNoteSound(pressedNote + "4");
                showFeedback("Correct!", true);
                isNoteAnswered = true;
                correctAnswers++; // ✅ Увеличиваем правильные ответы

                if (--remainingGames > 0) {
                    updateRemainingGamesText();
                } else {
                    finishSoloGame();
                }
            } else {
                mistakesCount++;
                showFeedback("Wrong! Correct: " + formatNoteName(currentNote), false);
            }
        };

        for (int key : whiteKeys) {
            parentView.findViewById(key).setOnClickListener(listener);
        }
        for (int key : blackKeys) {
            parentView.findViewById(key).setOnClickListener(listener);
        }
    }

    private void showFeedback(String message, boolean correct) {
        if (answerFeedbackText != null) {
            answerFeedbackText.setText(message);
            answerFeedbackText.setTextColor(correct ? 0xFF008800 : 0xFFFF0000);
            answerFeedbackText.setVisibility(View.VISIBLE);

            handler.postDelayed(() -> answerFeedbackText.setVisibility(View.INVISIBLE), 1000);
        }
    }

    private void showFeedbackIntervals(String message, boolean correct) {
        if (answerFeedbackTextIntervals != null) {
            answerFeedbackTextIntervals.setText(message);
            answerFeedbackTextIntervals.setTextColor(correct ? 0xFF008800 : 0xFFFF0000);
            answerFeedbackTextIntervals.setVisibility(View.VISIBLE);

            handler.postDelayed(() -> answerFeedbackTextIntervals.setVisibility(View.INVISIBLE), 1000);
        }
    }

    private String formatNoteName(String note) {
        return note.replace("sharp", "#").replaceAll("[0-9]", "").toUpperCase();
    }


    private String calculateInterval(String first, String second) {
        first = first.replace("sharp", "#");
        second = second.replace("sharp", "#");

        String[] allNotes = {
                "c3", "c#3", "d3", "d#3", "e3", "f3", "f#3", "g3", "g#3", "a3", "a#3", "b3",
                "c4", "c#4", "d4", "d#4", "e4", "f4", "f#4", "g4", "g#4", "a4", "a#4", "b4",
                "c5", "c#5", "d5", "d#5", "e5", "f5", "f#5", "g5", "g#5", "a5", "a#5", "b5"
        };

        int firstIndex = -1, secondIndex = -1;

        for (int i = 0; i < allNotes.length; i++) {
            if (allNotes[i].equals(first)) firstIndex = i;
            if (allNotes[i].equals(second)) secondIndex = i;
        }

        if (firstIndex == -1 || secondIndex == -1) {
            Log.e("IntervalError", "Interval calculation error: " + first + " - " + second);
            return "Unknown";
        }

        int distance = Math.abs(secondIndex - firstIndex);

        switch (distance) {
            case 0: return "Unison";
            case 1: return "Minor second";
            case 2: return "Major second";
            case 3: return "Minor third";
            case 4: return "Major third";
            case 5: return "Perfect fourth";
            case 6: return "Tritone";
            case 7: return "Perfect fifth";
            case 8: return "Minor sixth";
            case 9: return "Major sixth";
            case 10: return "Minor seventh";
            case 11: return "Major seventh";
            case 12: return "Octave";
            default: return "Unknown";
        }
    }
}