package com.example.eartraining2;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SoloModeFragment extends Fragment {

    private Spinner modeSpinner, difficultySpinner, testSizeSpinner;
    private Button playButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.solo_mode_interface, container, false);

        modeSpinner = view.findViewById(R.id.mode_selection_spinner);
        difficultySpinner = view.findViewById(R.id.difficulty_selection_spinner);
        testSizeSpinner = view.findViewById(R.id.test_size_spinner);
        playButton = view.findViewById(R.id.play_button_solo);

        playButton.setOnClickListener(v -> startSoloPlayActivity());

        return view;
    }

    private void startSoloPlayActivity() {
        Intent intent = new Intent(getActivity(), SoloPlayActivity.class);

        String selectedMode = modeSpinner.getSelectedItem().toString();
        String selectedDifficulty = difficultySpinner.getSelectedItem().toString();
        String selectedTestSize = testSizeSpinner.getSelectedItem().toString();

        intent.putExtra("selectedMode", selectedMode);
        intent.putExtra("selectedDifficulty", selectedDifficulty);
        intent.putExtra("selectedTestSize", selectedTestSize);

        startActivity(intent);
    }
}