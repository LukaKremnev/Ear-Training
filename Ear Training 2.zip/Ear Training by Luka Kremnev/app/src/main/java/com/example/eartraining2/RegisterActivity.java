package com.example.eartraining2;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.security.SecureRandom;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private EditText usernameInput, emailInput, passwordInput, confirmPasswordInput;
    private Button registerButton, loginButton;
    private Button homeButton, statisticsButton, settingsButton;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int ID_LENGTH = 6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        usernameInput = findViewById(R.id.username_input);
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
        confirmPasswordInput = findViewById(R.id.confirm_password_input);
        registerButton = findViewById(R.id.register_button);
        loginButton = findViewById(R.id.login_button);

        homeButton = findViewById(R.id.home_button);
        statisticsButton = findViewById(R.id.statistics_button);
        settingsButton = findViewById(R.id.settings_button);

        setupNavigation();

        updateUI();

        registerButton.setOnClickListener(v -> checkUsernameAndEmail());

        loginButton.setOnClickListener(v -> {
            if (auth.getCurrentUser() != null) {
                auth.signOut();
                Toast.makeText(RegisterActivity.this, "You have been logged out of your account.!", Toast.LENGTH_SHORT).show();
                updateUI();
            } else {
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                finish();
                overridePendingTransition(0, 0);
            }
        });
    }

    private void setupNavigation() {
        homeButton.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, MainActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        statisticsButton.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, StatisticsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });

        settingsButton.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, SettingsActivity.class));
            overridePendingTransition(0, 0);
            finish();
        });
    }

    private String generateUniqueId() {
        SecureRandom random = new SecureRandom();
        StringBuilder idBuilder = new StringBuilder(ID_LENGTH);

        for (int i = 0; i < ID_LENGTH; i++) {
            idBuilder.append(CHARACTERS.charAt(random.nextInt(CHARACTERS.length())));
        }

        return idBuilder.toString();
    }



    private void checkUsernameAndEmail() {
        Log.d("RegisterActivity", "Nickname and email verification has begun!");
        String username = usernameInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        String confirmPassword = confirmPasswordInput.getText().toString().trim();

        boolean hasError = false;

        // Проверка на пустые поля
        if (TextUtils.isEmpty(username)) {
            usernameInput.setError("Enter Nickname");
            usernameInput.requestFocus();
            hasError = true;
        }
        if (TextUtils.isEmpty(email)) {
            emailInput.setError("Enter Email");
            emailInput.requestFocus();
            hasError = true;
        }
        if (TextUtils.isEmpty(password)) {
            passwordInput.setError("Enter Password");
            passwordInput.requestFocus();
            hasError = true;
        }
        if (TextUtils.isEmpty(confirmPassword)) {
            confirmPasswordInput.setError("Enter Confirmation Password");
            confirmPasswordInput.requestFocus();
            hasError = true;
        }
        if (hasError) return;

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailInput.setError("Please enter a valid email");
            emailInput.requestFocus();
            return;
        }

        if (!password.equals(confirmPassword)) {
            confirmPasswordInput.setError("The passwords do not match");
            confirmPasswordInput.requestFocus();
            return;
        }

        db.collection("users").whereEqualTo("username", username).get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        if (!task.getResult().isEmpty()) {
                            usernameInput.setError("The nickname is already taken");
                            usernameInput.requestFocus();
                        } else {
                            checkEmailAndRegister(username, email, password);
                        }
                    } else {
                        Toast.makeText(RegisterActivity.this, "Connection error. Try again.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void checkEmailAndRegister(String username, String email, String password) {
        auth.fetchSignInMethodsForEmail(email)
                .addOnCompleteListener(emailCheckTask -> {
                    if (emailCheckTask.isSuccessful() && emailCheckTask.getResult().getSignInMethods() != null
                            && !emailCheckTask.getResult().getSignInMethods().isEmpty()) {
                        emailInput.setError("Email already in use");
                        emailInput.requestFocus();
                    } else {
                        registerUser(username, email, password);
                    }
                });
    }

    private void registerUser(String username, String email, String password) {
        Log.d("RegisterActivity", "Registration of new user: " + username + ", " + email);

        auth.setLanguageCode("en");
        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (!task.isSuccessful() || auth.getCurrentUser() == null) {
                        try {
                            throw task.getException();
                        } catch (FirebaseAuthUserCollisionException e) {
                            emailInput.setError("This email is already in use");
                            emailInput.requestFocus();
                        } catch (Exception e) {
                            emailInput.setError("Registration error: " + e.getMessage());
                            emailInput.requestFocus();
                        }
                        return;
                    }

                    String userId = auth.getCurrentUser().getUid();
                    String uniqueId = generateUniqueId();

                    Map<String, Object> user = new HashMap<>();
                    user.put("username", username);
                    user.put("email", email);
                    user.put("uniqueId", uniqueId);

                    db.collection("users").document(userId).set(user)
                            .addOnSuccessListener(aVoid -> showSuccessDialog())
                            .addOnFailureListener(e -> emailInput.setError("Error saving data"));
                });
    }

    private void updateUI() {
        FirebaseUser user = auth.getCurrentUser();
        if (user != null) {
            emailInput.setText(user.getEmail());
            passwordInput.setText("********");
            confirmPasswordInput.setText("********");

            emailInput.setEnabled(false);
            passwordInput.setEnabled(false);
            confirmPasswordInput.setEnabled(false);
            registerButton.setEnabled(false);

            loginButton.setText("Sign Out");
        } else {
            emailInput.setText("");
            passwordInput.setText("");
            confirmPasswordInput.setText("");

            emailInput.setEnabled(true);
            passwordInput.setEnabled(true);
            confirmPasswordInput.setEnabled(true);
            registerButton.setEnabled(true);

            loginButton.setText("Login");
        }
    }

    private void showSuccessDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Registration successful!")
                .setMessage("Now you can enjoy the app!")
                .setPositiveButton("Home", (dialogInterface, which) -> {
                    startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                    finish();
                })
                .setCancelable(false)
                .create();

        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positiveButton.setTextColor(getResources().getColor(R.color.white)); // Цвет текста
            positiveButton.setBackgroundColor(getResources().getColor(R.color.custom_color)); // Цвет фона
        });

        dialog.show();
    }
}