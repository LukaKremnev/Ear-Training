#include "fluid_synth.h"
#include "fluid_settings.h"

void fluid_shell_settings(fluid_settings_t* settings)
{
    // NOOP
}
  