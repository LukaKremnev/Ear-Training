import { GraphicalGlissando } from "../GraphicalGlissando";
import Vex from "vexflow";
import VF = Vex.Flow;

export class VexFlowGlissando extends GraphicalGlissando {
    public vfTie: VF.StaveTie;
}
