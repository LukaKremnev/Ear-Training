export enum SystemLinePosition {
    MeasureBegin,
    MeasureEnd
}
