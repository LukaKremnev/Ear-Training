import {GraphicalObject} from "./GraphicalObject";

export class Clickable extends GraphicalObject {
    public dataObject: Object;
}
