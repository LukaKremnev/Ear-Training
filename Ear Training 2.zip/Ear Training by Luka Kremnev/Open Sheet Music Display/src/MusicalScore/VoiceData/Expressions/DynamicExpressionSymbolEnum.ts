export enum DynamicExpressionSymbolEnum {
    p = 0,
    f = 1,
    s = 2,
    z = 3,
    m = 4,
    r = 5
}
