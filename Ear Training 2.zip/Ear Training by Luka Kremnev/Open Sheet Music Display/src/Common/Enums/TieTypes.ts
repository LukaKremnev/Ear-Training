/**
 * The types of ties available
 */
export enum TieTypes {
    "SIMPLE" = "",
    "HAMMERON" = "H",
    "PULLOFF" = "P",
    "SLIDE" = "S",
    "TAPPING" = "T"
}
