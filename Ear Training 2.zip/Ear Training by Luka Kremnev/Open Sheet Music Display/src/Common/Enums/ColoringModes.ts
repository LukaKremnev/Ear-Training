export enum ColoringModes {
    XML = 0,
    AutoColoring = 1,
    CustomColorSet = 2
}
// note that this is moved here from DrawingParameters to prevent an import chain to EngravingRules etc
